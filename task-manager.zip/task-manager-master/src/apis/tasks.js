import axios from 'axios';

export default axios.create({
  // FULL URL WOULD GO HERE E.G. https://api.domain.com/
  baseURL: ''
});
