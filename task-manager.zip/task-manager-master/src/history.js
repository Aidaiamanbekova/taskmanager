import { createBrowserHistory as createHistory } from 'history';

export default createHistory();
