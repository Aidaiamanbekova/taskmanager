Task Manager

React, Redux
